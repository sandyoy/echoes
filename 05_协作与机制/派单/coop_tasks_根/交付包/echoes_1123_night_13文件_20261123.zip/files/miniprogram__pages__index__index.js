/**
 * pages/index/index.js — 首页（双界面）
 * 标准版：定稿图「首页定稿_候选A_柔和版.png」形态 —— 顶部标题+副标+头像，主区三块平级卡
 *         （橙「自己说」/ 青「有人问我」/ 时间轴+我的书两小卡），下面「我的故事」列表
 * 大字版：就一个大按钮「按住说话」，其余收起（v2.4 §3.3）
 *
 * 登录态（小鲸鱼 09-29《接口定义_登录态v1》）：进小程序第一件事
 *   wx.login() → POST /api/echoes/login → user_id + profile.ui_mode + count_stories
 *   首页红点的 N 直接取登录返回的 count_stories（后端算，前端只显示），
 *   不再单独调 claim/login（该接口仍在，供按手机号自动认领场景）。
 *
 * ⚠️ 大字版禁词（v2.4 §3.3）：凡出现「设置/权限/分享」字样即为失败。
 *    提到数那行在**大字版不显示**（首页大字版只有「按住说话」+「更多」），
 *    避免任何复杂元素；红点只在标准版露出。
 */
const app = getApp();
const api = require('../../utils/api.js');

Page({
  data: {
    uiMode: 'standard',
    holding: false,
    stories: [],            // 故事列表（当前本地占位；P0-2 接 /story/list 后换真数据）
    mentionedCount: 0,      // 有 N 篇故事提到了你（后端算，前端只显示）
    loginReady: false,      // 登录是否已成功（真登录态）
    loginError: '',         // 登录失败原因（2026-10-27：不再静默，显式提示 + 可重试）
    showDiag: false,        // 自测面板是否展开
    diagLines: [],          // 自测日志行（app.diag 转成字符串）
    isNewUser: false,       // 首次进来（按此决定引导，v2.4）
    avatarText: '我',       // 右上角头像里的字（有昵称取首字）
    busy: false
  },

  onShow() {
    this.setData({ uiMode: app.getUiMode() });
    this.refreshMentioned();
    this.loadStories();
  },

  /**
   * ★ 2026-10-31：首页「我的故事」原来恒显示「还没有故事」（stories 从没被赋值过），
   * 于是用户看不到自己录的东西、也进不去故事详情 —— 表现为「存了也列不出来」。
   * 现在登录落定后拉 /story/list，把真数据填进来。
   */
  loadStories() {
    app.ensureLogin().then(() => {
      const g = app.globalData || {};
      const uid = g.userId || '';
      if (!uid) return;
      api.storyList(uid, { viewerId: uid }).then((d) => {
        const list = (d && d.stories) || [];
        this.setData({
          stories: list.map((s) => ({
            id: s.story_id,
            title: s.title || '这段你还没起名，点一下起个名',
            timeRaw: s.time_raw || '',
            updatedAt: s.updated_at || s.created_at || ''
          }))
        });
      }).catch(() => { /* 列表拉不到不打断首页，保留上一次的 */ });
    }).catch(() => null);
  },

  /**
   * 拉「有 N 篇故事提到了你」。
   * 登录（app.ensureLogin，onLaunch 已发起）落定后同步一次；未登录时用缓存值，不发请求。
   */
  refreshMentioned() {
    const cache = api.getMentionedCache();
    this.setData({ mentionedCount: Number(cache.count || 0) });
    app.ensureLogin().then(() => {
      const g = app.globalData;
      // 2026-10-27：登录失败不再静默 —— 把原因带到页面上，用户能看到"为什么点了没反应"
      if (!g.loginReady) {
        this.setData({
          loginReady: false,
          loginError: g.loginError || (g.loginPending ? '正在登录，稍等' : '登录没成功')
        });
        return;
      }
      const c = api.getMentionedCache();
      this.setData({
        mentionedCount: Number(c.count || 0),
        loginReady: true,
        loginError: '',
        isNewUser: !!g.isNewUser,
        uiMode: app.getUiMode()          // 登录会应用 profile.ui_mode
      });
    }).catch(() => null);
  },

  /** 展开/收起自测面板（2026-10-27） */
  onToggleDiag() {
    const next = !this.data.showDiag;
    const lines = (app.diag || []).map((l) => l.t + ' ' + l.step + ' ' + JSON.stringify(l.extra || {}));
    this.setData({ showDiag: next, diagLines: lines });
  },

  /** 复制自测日志（发给技术看，或自己留着对比） */
  onCopyDiag() {
    const text = (app.diag || []).map((l) => l.t + ' ' + l.step + ' ' + JSON.stringify(l.extra || {})).join('\n');
    wx.setClipboardData({
      data: text || '（还没有自测记录）',
      success: () => wx.showToast({ title: '已复制', icon: 'success' })
    });
  },

  /** 登录失败条点一下 → 重试登录（2026-10-27） */
  onRetryLogin() {
    const g = app.globalData;
    if (g.loginPending) { wx.showToast({ title: '正在登录', icon: 'none' }); return; }
    g.loginError = '';
    g.userId = '';
    g.loginReady = false;
    this.setData({ loginError: '' });
    wx.showLoading({ title: '正在登录' });
    app.ensureLogin().then(() => {
      wx.hideLoading();
      if (app.globalData.userId) {
        this.setData({ loginReady: true, loginError: '' });
        wx.showToast({ title: '登录好了', icon: 'success' });
      } else {
        this.setData({ loginError: app.globalData.loginError || '还是没成功' });
      }
    });
  },

  /** 点「有 N 篇故事提到了你」→ 进入待认领页（列出提到自己的故事） */
  onOpenMentioned() {
    if (this.data.mentionedCount <= 0) return;
    wx.navigateTo({ url: '/pages/claim/claim' });
  },

  /** 右上角头像：暂进「家里人」页（个人资料页尚未设计，不新造空页）
   *  ★ 11-10：family 在 tabBar 里，navigateTo 必失败 → switchTab */
  onOpenAvatar() {
    wx.switchTab({
      url: '/pages/family/family',
      fail: () => {
        wx.showToast({ title: '没打开，请再点一次', icon: 'none' });
      }
    });
  },

  /** 切换标准版 / 大字版（v2.4 §3.2：随时可切） */
  onToggleMode() {
    const next = app.getUiMode() === 'large' ? 'standard' : 'large';
    app.setUiMode(next);
    this.setData({ uiMode: next });
  },

  /** 大字版主入口：按住说话 → 采集页（录音在采集页真做）
   *  ★ 11-23 修：原来只有 bindtouchstart 跳页、没有任何反馈，老人手指按下去
   *    页面就跳走了，感觉「按了没反应 / 说不了话」。现在按下给震动+按钮变红，
   *    松手才跳，跳过去的采集页圆圈已修好（不再被保存键盖住）。 */
  onHoldStart() {
    this.setData({ holding: true });
    wx.vibrateShort && wx.vibrateShort({ type: 'medium' });
  },

  onHoldEnd() {
    if (!this.data.holding) return;
    this.setData({ holding: false });
    wx.navigateTo({ url: '/pages/capture/capture?type=voice' });
  },

  /** 卡1「现在就说」→ 进采集页（语音）。进门默认语音，其余录法在采集页里选 */
  onCaptureVoice() {
    wx.navigateTo({ url: '/pages/capture/capture?type=voice' });
  },

  /** 标准版：进入采集页（文字/语音/照片/视频 四类） */
  onCapture(e) {
    const type = (e && e.currentTarget && e.currentTarget.dataset.type) || 'text';
    wx.navigateTo({ url: `/pages/capture/capture?type=${type}` });
  },

  /** 卡2「开始聊」= 采访（v3.0 §6.0/§7.1：独立入口、与自述平级，直接进对话框） */
  onOpenInterview() {
    wx.navigateTo({
      url: '/pages/interview/interview',
      fail: () => {
        wx.showToast({ title: '采访没打开，请再点一次', icon: 'none' });
      }
    });
  },

  /**
   * 卡3「时间轴」（灵魂功能，v3.0 §五：时间轴是目录、故事是章节）
   * ★ 11-10 sandy 实测「点不进去」——根因：timeline 在 tabBar 里，
   *   navigateTo 跳 tabBar 页【必然失败】，而 fail 又是空的 → 点了毫无反应。
   *   铁律：跳 tabBar 页只能 switchTab。
   */
  onOpenTimeline() {
    wx.switchTab({
      url: '/pages/timeline/timeline',
      fail: () => {
        wx.showToast({ title: '没打开，请再点一次', icon: 'none' });
      }
    });
  },

  /** 点故事卡 → 看故事详情（P0-2 新建 pages/story） */
  onTapStory(e) {
    const sid = (e && e.currentTarget && e.currentTarget.dataset.storyId) || '';
    if (!sid) return;
    wx.navigateTo({
      url: '/pages/story/story?story_id=' + encodeURIComponent(sid),
      fail: () => {
        wx.showToast({ title: '没打开，请再点一次', icon: 'none' });
      }
    });
  },

  /** 卡3「我的书」→ 成书页（★ book 也在 tabBar 里，必须 switchTab，否则静默失败） */
  onOpenBook() {
    wx.switchTab({
      url: '/pages/book/book',
      fail: () => {
        wx.showToast({ title: '没打开，请再点一次', icon: 'none' });
      }
    });
  },

  /** 家人页（v3.0 §2.2/§2.3）：family 在 tabBar 里 → switchTab */
  onOpenFamily() {
    wx.switchTab({
      url: '/pages/family/family',
      fail: () => {
        wx.showToast({ title: '没打开，请再点一次', icon: 'none' });
      }
    });
  }
});
